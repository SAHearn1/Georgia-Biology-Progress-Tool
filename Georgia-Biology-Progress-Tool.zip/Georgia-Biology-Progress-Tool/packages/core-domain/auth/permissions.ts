export type Role = "TEACHER" | "DEPT_LEAD" | "ADMIN";

const roleHierarchy: Record<Role, number> = {
  TEACHER: 1,
  DEPT_LEAD: 2,
  ADMIN: 3,
};

/**
 * Returns true if the user role has at least the privileges of the required role.
 */
export function canAccess(userRole: Role, requiredRole: Role): boolean {
  return roleHierarchy[userRole] >= roleHierarchy[requiredRole];
}