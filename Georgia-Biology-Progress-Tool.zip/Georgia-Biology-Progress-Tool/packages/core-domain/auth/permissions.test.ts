import { test, strict as assert } from "node:test";
import { canAccess } from "./permissions";

test("admin can access teacher resources", () => {
  assert.equal(canAccess("ADMIN", "TEACHER"), true);
});

test("teacher cannot access admin resources", () => {
  assert.equal(canAccess("TEACHER", "ADMIN"), false);
});