"use client";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = await signIn("credentials", {
      redirect: false,
      email,
      password,
    });
    if (!result?.error) {
      router.push("/");
    } else {
      alert("Invalid credentials");
    }
  };

  return (
    <section className="flex items-center justify-center min-h-screen bg-root-cream">
      <form
        className="bg-white p-8 shadow-card rounded-card w-full max-w-md"
        onSubmit={handleSubmit}
      >
        <h1 className="text-2xl font-semibold mb-6 text-center text-root-canopy">
          Login
        </h1>
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1 text-root-canopy">
            Email
          </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full border border-neutralBorder rounded-md p-2"
            required
          />
        </div>
        <div className="mb-6">
          <label className="block text-sm font-medium mb-1 text-root-canopy">
            Password
          </label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border border-neutralBorder rounded-md p-2"
            required
          />
        </div>
        <button
          type="submit"
          className="w-full bg-root-green text-white py-2 rounded-md hover:bg-root-canopy"
        >
          Sign In
        </button>
      </form>
    </section>
  );
}