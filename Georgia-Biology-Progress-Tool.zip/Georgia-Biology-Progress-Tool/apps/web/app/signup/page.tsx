"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function SignupPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const router = useRouter();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, name }),
    });
    if (res.ok) {
      // redirect to login on success
      router.push("/login");
    } else {
      const data = await res.json();
      alert(data.error || "Signup failed");
    }
  }

  return (
    <section className="flex items-center justify-center min-h-screen bg-root-cream">
      <form
        className="bg-white p-8 shadow-card rounded-card w-full max-w-md"
        onSubmit={handleSubmit}
      >
        <h1 className="text-2xl font-semibold mb-6 text-center text-root-canopy">
          Sign Up
        </h1>
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1 text-root-canopy">
            Name
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full border border-neutralBorder rounded-md p-2"
            required
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1 text-root-canopy">
            Email
          </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full border border-neutralBorder rounded-md p-2"
            required
          />
        </div>
        <div className="mb-6">
          <label className="block text-sm font-medium mb-1 text-root-canopy">
            Password
          </label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border border-neutralBorder rounded-md p-2"
            required
          />
        </div>
        <button
          type="submit"
          className="w-full bg-root-green text-white py-2 rounded-md hover:bg-root-canopy"
        >
          Create Account
        </button>
      </form>
    </section>
  );
}