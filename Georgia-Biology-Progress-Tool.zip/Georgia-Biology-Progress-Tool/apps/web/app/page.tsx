export default function Home() {
  return (
    <section>
      <h1 className="text-2xl font-semibold mb-4">
        Welcome to the Georgia Biology Progress Monitoring Tool
      </h1>
      <p className="text-neutralText">
        Use the navigation bar to access classes and assessments.
      </p>
    </section>
  );
}