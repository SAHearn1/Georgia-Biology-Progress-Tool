import "./globals.css";
import type { ReactNode } from "react";

export const metadata = {
  title: "Georgia Biology Progress Monitoring",
  description: "Track student mastery of Georgia Biology standards.",
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-root-cream text-root-canopy">
        <header className="bg-root-green text-white shadow p-4">
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2">
              {/* Logo placeholder */}
              <span className="text-xl font-bold">
                Georgia Biology Progress Monitoring
              </span>
            </div>
            {/* User menu placeholder */}
          </div>
        </header>
        <main className="min-h-screen">
          <div className="mx-auto max-w-6xl px-4 py-8">{children}</div>
        </main>
      </body>
    </html>
  );
}