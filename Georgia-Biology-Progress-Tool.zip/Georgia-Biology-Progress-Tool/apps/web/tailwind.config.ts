import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
    "./pages/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        root: {
          green: "#1B4332",
          gold: "#C9A961",
          canopy: "#102019",
          cream: "#F7F3EB",
          white: "#FFFFFF",
        },
        neutralBorder: "#E5E7EB",
        neutralTextMuted: "#9CA3AF",
        neutralText: "#4B5563",
      },
      borderRadius: {
        card: "0.75rem",
      },
      boxShadow: {
        card: "0 4px 10px rgba(0, 0, 0, 0.06)",
      },
    },
  },
  plugins: [],
};

export default config;