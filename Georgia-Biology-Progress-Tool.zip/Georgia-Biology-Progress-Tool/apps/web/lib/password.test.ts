import { test, strict as assert } from "node:test";
import { hash, compare } from "bcryptjs";

test("password hashing and verification", async () => {
  const password = "s3cr3t";
  const hashed = await hash(password, 10);
  const match = await compare(password, hashed);
  assert.equal(match, true);
});