# Georgia Biology Progress Monitoring Tool

Welcome to the **Georgia Biology Progress Monitoring Tool** — a teacher‑facing web application designed to help biology educators track student mastery of Georgia Biology standards. This project is part of the **RootWork Framework™ / From Garden to Growth™** ecosystem and aims to deliver actionable insights while remaining privacy‑respectful and standalone.

## Project Goals

- Provide teachers with a clean, zero‑click dashboard to view class and student progress.
- Allow creation of classes and rosters without requiring a school district’s SIS or LMS integration (integrations are optional adapters).
- Scaffold assessments, store student responses, and surface mastery projections.
- Leverage a modular monolithic architecture that can evolve into services over time.

## Getting Started

1. Copy `.env.example` to `.env` and fill in your local environment variables (database URL, NextAuth secret, etc.).
2. Install dependencies and run the development server from within the `apps/web` directory:

   ```bash
   cd apps/web
   npm install
   npm run dev
   ```

3. Run Prisma migrations to provision your database:

   ```bash
   npx prisma migrate dev --schema=../../prisma/schema.prisma
   ```

For a deeper dive into the system context, internal architecture, and step‑by‑step development phases, please refer to the architecture documentation provided alongside this project.